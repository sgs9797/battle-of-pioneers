'use client'
import { useState } from 'react'

type Cell = { hasShip:boolean; state:'empty'|'hit'|'miss' }
type Phase = 'entry'|'placement'|'battle'|'gameover'

const makeGrid = () =>
  Array.from({length:6},()=>Array.from({length:6},()=>({hasShip:false,state:'empty' as const})))

const placeRandomShips = (grid:Cell[][]) => {
  let p=0
  while(p<5){
    const r=Math.floor(Math.random()*6), c=Math.floor(Math.random()*6)
    if(!grid[r][c].hasShip){ grid[r][c].hasShip=true; p++ }
  }
}

export default function Page(){
  const ENTRY_FEE = 1
  const PLATFORM_FEE = 0.1

  const [balance,setBalance]=useState(10)
  const [phase,setPhase]=useState<Phase>('entry')
  const [myGrid,setMyGrid]=useState<Cell[][]>(makeGrid)
  const [botGrid,setBotGrid]=useState<Cell[][]>(makeGrid)
  const [placed,setPlaced]=useState(0)
  const [isMyTurn,setIsMyTurn]=useState(true)
  const [winner,setWinner]=useState<'me'|'bot'|null>(null)
  const [lock,setLock]=useState(false)
  const [message,setMessage]=useState('')

  const checkWin = (g:Cell[][])=>g.every(r=>r.every(c=>!c.hasShip||c.state==='hit'))

  const toggleShip=(r:number,c:number)=>{
    if(phase!=='placement') return
    setMyGrid(g=>{
      const ng=g.map(row=>row.map(c=>({...c})))
      if(!ng[r][c].hasShip&&placed<5){ ng[r][c].hasShip=true; setPlaced(p=>p+1) }
      else if(ng[r][c].hasShip){ ng[r][c].hasShip=false; setPlaced(p=>p-1) }
      return ng
    })
  }

  const botMove=()=>{
    setLock(true)
    setMyGrid(g=>{
      const ng=g.map(row=>row.map(c=>({...c})))
      let r,c
      do{ r=Math.floor(Math.random()*6); c=Math.floor(Math.random()*6) }while(ng[r][c].state!=='empty')
      ng[r][c].state = ng[r][c].hasShip?'hit':'miss'
      if(ng[r][c].state==='hit'){
        setMessage('Bot hit your ship!')
        if(checkWin(ng)){
          setWinner('bot')
          setBalance(b=>b-ENTRY_FEE)
          setPhase('gameover')
        } else setTimeout(botMove,700)
      } else {
        setMessage('Bot missed!')
        setIsMyTurn(true)
      }
      setLock(false)
      return ng
    })
  }

  const attack=(r:number,c:number)=>{
    if(phase!=='battle'||!isMyTurn||lock||botGrid[r][c].state!=='empty') return
    setLock(true)
    setBotGrid(g=>{
      const ng=g.map(row=>row.map(c=>({...c})))
      ng[r][c].state = ng[r][c].hasShip?'hit':'miss'
      if(ng[r][c].state==='hit'){
        setMessage('You hit a ship!')
        if(checkWin(ng)){
          setWinner('me')
          setBalance(b=>b+(ENTRY_FEE*2-PLATFORM_FEE))
          setPhase('gameover')
        }
      } else {
        setMessage('You missed!')
        setIsMyTurn(false)
        setTimeout(botMove,700)
      }
      setLock(false)
      return ng
    })
  }

  if(phase==='entry'){
    return (
      <div style={{padding:24}}>
        <h2>Battle Entry</h2>
        <p>Your Balance: {balance} Test Pi</p>
        <p>Entry Fee: {ENTRY_FEE} Test Pi</p>
        <p>Platform Fee: {PLATFORM_FEE} Test Pi</p>
        <button disabled={balance<ENTRY_FEE} onClick={()=>setPhase('placement')}>
          Join Battle
        </button>
      </div>
    )
  }

  if(phase==='gameover'){
    return (
      <div style={{height:'100vh',display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center'}}>
        <h1>{winner==='me'?'🎉 You Won!':'💀 You Lost'}</h1>
        <p>Balance: {balance} Test Pi</p>
        <button onClick={()=>location.reload()}>Play Again</button>
      </div>
    )
  }

  return (
    <div style={{padding:16}}>
      {phase==='placement' && (
        <>
          <h2>Place your 5 ships</h2>
          <p>Ships placed: {placed} / 5</p>
          <div style={{display:'grid',gridTemplateColumns:'repeat(6,40px)',gap:4}}>
            {myGrid.map((row,r)=>row.map((c,i)=>(
              <div key={r+'-'+i} onClick={()=>toggleShip(r,i)}
                style={{width:40,height:40,background:c.hasShip?'#003366':'#4aa'}}/>
            )))}
          </div>
          <button disabled={placed!==5} onClick={()=>{
            const g=makeGrid(); placeRandomShips(g)
            setBotGrid(g); setPhase('battle')
          }}>Start Battle</button>
        </>
      )}

      {phase==='battle' && (
        <>
          <h3>{isMyTurn?'Your Turn':'Bot Turn'}</h3>
          <p>{message}</p>
          <div style={{display:'flex',gap:16}}>
            <div>
              <h4>Your Fleet</h4>
              <div style={{display:'grid',gridTemplateColumns:'repeat(6,36px)',gap:3}}>
                {myGrid.map((row,r)=>row.map((c,i)=>(
                  <div key={r+'-'+i}
                    style={{width:36,height:36,
                      background:c.state==='hit'?'red':c.state==='miss'?'gray':c.hasShip?'#003366':'#4aa'}}/>
                )))}
              </div>
            </div>
            <div>
              <h4>Enemy Waters</h4>
              <div style={{display:'grid',gridTemplateColumns:'repeat(6,36px)',gap:3}}>
                {botGrid.map((row,r)=>row.map((c,i)=>(
                  <div key={r+'-'+i} onClick={()=>attack(r,i)}
                    style={{width:36,height:36,
                      background:c.state==='hit'?'red':c.state==='miss'?'gray':'#4aa'}}/>
                )))}
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  )
}
